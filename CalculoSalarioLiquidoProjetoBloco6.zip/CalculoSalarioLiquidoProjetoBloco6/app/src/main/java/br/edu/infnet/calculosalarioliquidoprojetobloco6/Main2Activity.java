package br.edu.infnet.calculosalarioliquidoprojetobloco6;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;

public class Main2Activity extends AppCompatActivity {

    private TextView salarioLiquido;
    private TextView descontos;
    private TextView porcentagem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        salarioLiquido = (TextView) findViewById(R.id.salLiqId);
        descontos = (TextView) findViewById(R.id.descId);
        porcentagem = (TextView) findViewById(R.id.porcId);

        Intent intent = getIntent();
        Double SL = intent.getDoubleExtra("SLAdd",0);
        Double D = intent.getDoubleExtra("DAdd", 0);
        Double P = intent.getDoubleExtra("PAdd", 0);

        DecimalFormat formatador = new DecimalFormat("0.00");

        salarioLiquido.setText("R$ " + formatador.format(SL));
        descontos.setText("R$ " + formatador.format(D));
        porcentagem.setText(formatador.format(P) + "%");

    }
}
