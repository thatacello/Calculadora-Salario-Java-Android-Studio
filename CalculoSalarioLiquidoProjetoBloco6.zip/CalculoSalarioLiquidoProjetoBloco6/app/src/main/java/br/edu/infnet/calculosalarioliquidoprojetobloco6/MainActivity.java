package br.edu.infnet.calculosalarioliquidoprojetobloco6;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.DecimalFormat;

public class MainActivity extends AppCompatActivity {

    private EditText salarioBruto;
    private EditText dependentes;
    private EditText pensao;
    private EditText planoSaude;
    private EditText outros;
    private Button botao;

    double INSS;
    double IRPF;
    float SB;
    int DP ;
    float PEN ;
    float PS ;
    float O;
    double SL;
    double P;
    double D;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        salarioBruto = (EditText) findViewById(R.id.salarioId);
        dependentes = (EditText) findViewById(R.id.dependentesId);
        pensao = (EditText) findViewById(R.id.pensaoId);
        planoSaude = (EditText) findViewById(R.id.planoSaudeId);
        outros = (EditText) findViewById(R.id.outrosId);
        botao = (Button) findViewById(R.id.botaoId);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (salarioBruto.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Digite o Salário Bruto", Toast.LENGTH_LONG).show();
                } else {

                    SB = Float.parseFloat(salarioBruto.getText().toString());


                    if (SB <= 1659.38) {
                        INSS = (SB * 0.08);
                    } else if (SB >= 1659.39 && SB <= 2765.66) {
                        INSS = (SB * 0.09);
                    } else if (SB >= 2765.67 && SB <= 5531.31) {
                        INSS = (SB * 0.11);
                    } else {
                        INSS = 608.44;
                    }

                    if (SB <= 1903.98) {
                        IRPF = (SB * 0);
                    } else if (SB >= 1903.99 && SB <= 2826.65) {
                        IRPF = (SB * 0.075);
                    } else if (SB >= 2826.66 && SB <= 3751.05) {
                        IRPF = (SB * 0.15);
                    } else if (SB <= 3751.06 && SB >= 4664.68) {
                        IRPF = (SB * 0.225);
                    } else {
                        IRPF = (SB * 0.275);
                    }

                    DP = Integer.valueOf(dependentes.getText().toString());
                    PEN = Float.valueOf(pensao.getText().toString());
                    PS = Float.valueOf(planoSaude.getText().toString());
                    O = Float.valueOf(outros.getText().toString());

                    SL = ( SB - INSS - IRPF - PEN - PS - O - (DP * 189.59) );
                    D = ( INSS + IRPF + PEN + PS + O + (DP * 189.59) );
                    P = ((D * 100) / SB);


                Intent intent = new Intent(MainActivity.this, Main2Activity.class);
                intent.putExtra("SLAdd", SL);
                intent.putExtra("DAdd", D);
                intent.putExtra("PAdd", P);
                startActivity(intent);
                }

            }
        });



    }
}